//swiper
const swiperSlides = document.getElementsByClassName("swiper-slide");
const breakPoint = 769; // ブレークポイントを設定
let swiper;
let swiperBool;

window.addEventListener(
	"load",
	() => {
		if (breakPoint < window.innerWidth) {
			swiperBool = false;
		} else {
			createSwiper();
			swiperBool = true;
		}
	},
	false
);

window.addEventListener(
	"resize",
	() => {
		if (breakPoint < window.innerWidth && swiperBool) {
			swiper.destroy(false, true);
			swiperBool = false;
		} else if (breakPoint >= window.innerWidth && !swiperBool) {
			createSwiper();
			swiperBool = true;
		}
	},
	false
);

const createSwiper = () => {
	swiper = new Swiper("#js_swiper", {
		loop: true,
		speed: 400,
		navigation: {
			nextEl: ".pg_swiper_next",
			prevEl: ".pg_swiper_prev",
		},
		// aria-labelの内容を変更
		a11y: {
		  prevSlideMessage: '前のスライドへ',
		  nextSlideMessage: '次のスライドへ',
		  firstSlideMessage: '最初のスライド',
		  lastSlideMessage: '最後のスライド',
		},
	});
};