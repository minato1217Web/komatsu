//zipcloud API
document.addEventListener('DOMContentLoaded', function () {
	// 各要素を取得
	const zipInput = document.getElementById('js_zip');
	const zipBtn = document.getElementById('js_zip_btn');
	const prefInput = document.getElementById('js_pref');
	const municipalitiesInput = document.getElementById('js_municipalities');

	// 郵便番号検索ボタンがクリックされたときの処理
	zipBtn.addEventListener('click', function () {
		// 郵便番号を取得
		const zip = zipInput.value;
		// zipcloud APIのURLを作成
		const url = `https://zipcloud.ibsnet.co.jp/api/search?zipcode=${zip}`;

		// APIを呼び出し
		fetch(url)
			.then((response) => response.json())
			.then((data) => {
				// ステータスが200の場合、住所を取得して入力欄に設定
				if (data.status === 200) {
					const addressData = data.results[0];
					prefInput.value = addressData.address1;
					municipalitiesInput.value = addressData.address2 + addressData.address3;
				} else {
					// エラーメッセージを表示
					console.error('Error:', data.message);
				}
			})
			.catch((error) => {
				// エラーが発生した場合、エラーメッセージを表示
				console.error('Error:', error);
			});
	});
});