/* =========================================
メインビュー  下から上へスライド
========================================= */
document.addEventListener("DOMContentLoaded", function() {
	const container = document.querySelector('.js_mv_gallery');
	const imgElement = document.querySelector('.pg_mv_gallery_img');
	
	// 画像を複製
	const clonedImgElement = imgElement.cloneNode(true);
	container.appendChild(clonedImgElement);
	
	let startTime = null;
	
	// アニメーション時間（秒）
	const duration = 150;
	
	function animate(time) {
		if (startTime === null) startTime = time;
	
		// 経過時間
		const elapsed = (time - startTime) / 1000;
	
		// トランスレーションの位置を計算（-100% 相当の動き）
		const translateY = -((elapsed % duration) / duration) * imgElement.clientHeight;
	
		// 位置を適用
		[imgElement, clonedImgElement].forEach((img, index) => {
			const offset = index * img.clientHeight;
			img.style.transform = `translateY(${translateY + offset}px)`;
		});
	
		// アニメーションループ
		requestAnimationFrame(animate);
	}
	
	// アニメーション開始
	requestAnimationFrame(animate);
});
